<?php

return [
    // -------- Menu---------
    'dashboard' => 'Dashboard',
    'details' =>'Details',
    'order_module' => 'Order Module',
    'order' =>'orders',
    'send_offer' =>'Send Offer',
    'accept_order' => 'accept_order',
    'transactions_module' => '',
    'transactions' =>'transactions',
    'accept_transaction' => 'accept_transaction',

    'customer_module' => '',
    'customer' => 'customer',
    'provider_module' => '',
    'provider' => 'provider',
    'notification_module' => '',
    'notification' =>'notification',

    'system_settings' => '',
    'transporters' =>'transporters',
    'cy_periodics' =>'cy_periodics',
    'tires' => 'tires',
    'type_batteries' => 'type_batteries',
    'type_gasolines' => 'type_gasolines',
    'vehicle_brands' => 'vehicle_brands',
    'vehicle_models' => 'vehicle_models',
    'vehicle_types' => 'vehicle_types',
    'vehicle_manufacture_years' => 'vehicle_manufacture_years',
    'settings' =>'',
    'service' => 'service',
    'banks' => 'banks',
    'icons' => 'icons',
    'category' => 'category',
    'slider' => 'slider',
    'splash_screen' => 'splash_screen',
    'countries' => 'countries',
    'city' => 'city',
    'areas' => 'areas',
    'general_settings' => 'general_settings',

    'messages' => '',
    'contact_us' => 'contact_us',

    'admin_module' => '',
    'admins' => 'admins',

];
