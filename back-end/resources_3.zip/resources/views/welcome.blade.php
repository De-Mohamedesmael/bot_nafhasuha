<!DOCTYPE html>
<html lang="en">
<head>
    <title>Nafhasuha</title>
</head>
<body class="dashboard dashboard_1">
<div class="full_container">
    <div class="inner_container">
        <div id="content">
            <div class="midde_cont">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <h1> Welcome to Nafhasuha</h1>
                            <h3> Payment Result</h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
