<link rel="stylesheet" href="{{asset('assets/back-end/css/sweetalert2.min.css')}}">
<!-- Bootstrap CSS-->
<link rel="stylesheet" href="{{asset('assets/back-end/vendor/bootstrap/css/bootstrap.min.css')}}" type="text/css">
<link rel="stylesheet" href="{{asset('assets/back-end/vendor/bootstrap-toggle/css/bootstrap-toggle.min.css')}}" type="text/css">
<!-- Custom Scrollbar-->
<link rel="stylesheet" href="{{asset('assets/back-end/vendor/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.css')}}"
      type="text/css">
<link rel="stylesheet" href="{{asset('assets/back-end/vendor/bootstrap-datepicker/bootstrap-datepicker.min.css')}}" type="text/css">
<link rel="stylesheet" href="{{asset('assets/back-end/vendor/bootstrap-datetimepicker/bootstrap-datetimepicker.min.css')}}" type="text/css">

<link rel="stylesheet" href="{{asset('assets/back-end/vendor/jquery-timepicker/jquery.timepicker.min.css')}}" type="text/css">
<link rel="stylesheet" href="{{asset('assets/back-end/vendor/bootstrap/css/awesome-bootstrap-checkbox.css')}}" type="text/css">
<link rel="stylesheet" href="{{asset('assets/back-end/vendor/bootstrap/css/bootstrap-select.min.css')}}" type="text/css">
<!-- Font Awesome CSS-->
<link rel="stylesheet" href="{{asset('assets/back-end/vendor/font-awesome/css/font-awesome.min.css')}}" type="text/css">
<!-- Drip icon font-->
<link rel="stylesheet" href="{{asset('assets/back-end/vendor/dripicons/webfont.css')}}" type="text/css">
<!-- Google fonts - Roboto -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:400,500,700">
<!-- jQuery Circle-->
<link rel="stylesheet" href="{{asset('assets/back-end/css/grasp_mobile_progress_circle-1.0.0.min.css')}}" type="text/css">

<!-- virtual keybord stylesheet-->
<link rel="stylesheet" href="{{asset('assets/back-end/vendor/keyboard/css/keyboard.css')}}" type="text/css">
<!-- date range stylesheet-->
<link rel="stylesheet" href="{{asset('assets/back-end/vendor/daterange/css/daterangepicker.min.css')}}" type="text/css">
<!-- table sorter stylesheet-->
<link rel="stylesheet" href="{{asset('assets/back-end/vendor/datatable/dataTables.bootstrap4.min.css')}}" type="text/css">
<link rel="stylesheet" href="https://cdn.datatables.net/fixedheader/3.1.6/css/fixedHeader.bootstrap.min.css"
type="text/css">
<link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.bootstrap.min.css"
type="text/css">
<link rel="stylesheet" href="{{asset('assets/back-end/vendor/toastr/toastr.min.css')}}" id="theme-stylesheet" type="text/css">
<link rel="stylesheet" href="{{asset('assets/back-end/css/style.default.css')}}" id="theme-stylesheet" type="text/css">
<link rel="stylesheet" href="{{asset('assets/back-end/css/dropzone.css')}}">
<link rel="stylesheet" href="{{asset('assets/back-end/vendor/cropperjs/cropper.min.css') }}">
<link rel="stylesheet" href="{{asset('assets/back-end/css/bootstrap-treeview.css')}}">
<link rel="stylesheet" href="{{asset('assets/back-end/css/style.css')}}">


<!-- Custom stylesheet - for your changes-->
<link rel="stylesheet" href="{{asset('assets/back-end/css/custom-default.css') }}" type="text/css" id="custom-style">

<style>
    nav.navbar .nav-item a i {
        font-size: 25px;
    }
    .my-group .form-control {
        width: 50% !important;
    }

    .bs-searchbox .form-control {
        width: 100% !important;
    }

    .error {
        color: red !important;
    }

    .text-red {
        color: maroon !important;
    }

    .hide {
        display: none !important;
    }
</style>


