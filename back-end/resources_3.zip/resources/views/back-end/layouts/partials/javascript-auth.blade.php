
<script type="text/javascript" src="{{asset('assets/back-end/js/lang/'.session('language').'.js') }}"></script>
<script type="text/javascript" src="{{asset('assets/back-end/vendor/jquery/jquery.min.js') }}"></script>
<script type="text/javascript" src="{{asset('assets/back-end/vendor/jquery/jquery-ui.min.js') }}"></script>
<script type="text/javascript" src="{{asset('assets/back-end/vendor/jquery/jquery.timepicker.min.js') }}"></script>
<script type="text/javascript" src="{{asset('assets/back-end/vendor/popper.js/umd/popper.min.js') }}">
</script>
<script type="text/javascript" src="{{asset('assets/back-end/vendor/bootstrap/js/bootstrap.min.js') }}"></script>
<script type="text/javascript" src="{{asset('assets/back-end/vendor/daterange/js/moment.min.js') }}"></script>

<script type="text/javascript" src="{{asset('assets/back-end/vendor/bootstrap-datepicker/bootstrap-datepicker.min.js') }}"></script>
<script type="text/javascript" src="{{asset('assets/back-end/vendor/bootstrap-datepicker/locales/bootstrap-datepicker.'.session('language').'.min.js') }}"></script>
<script type="text/javascript" src="{{asset('assets/back-end/vendor/bootstrap-datetimepicker/bootstrap-datetimepicker.min.js')}}"></script>

<script type="text/javascript" src="{{asset('assets/back-end/vendor/bootstrap-toggle/js/bootstrap-toggle.min.js') }}"></script>
<script type="text/javascript" src="{{asset('assets/back-end/vendor/bootstrap/js/bootstrap-select.min.js') }}"></script>
