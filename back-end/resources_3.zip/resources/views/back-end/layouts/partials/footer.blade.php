<footer class="main-footer no-print">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <p>&copy; <a href="https://bot-ksa.com">bot-ksa</a>
                    <span class="">@lang('lang.developed_by') <a target="_blank" href="http://bot-ksa.com">bot-ksa</a></span></p>
            </div>
        </div>
    </div>
</footer>
