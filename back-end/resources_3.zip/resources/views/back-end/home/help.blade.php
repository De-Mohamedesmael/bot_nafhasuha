@extends('back-end.layouts.app')

@section('content')
<div class="row">
    <div class="container-fluid">
        <div class="col-md-12">
           {!! $help_page_content !!}
        </div>
    </div>
</div>
@endsection

@section('javascript')
<script>

</script>
@endsection
